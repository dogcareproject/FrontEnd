import Nav from "../components/Nav";

const AIModel = () => {
  return <div>
  </div>
};

export default AIModel;