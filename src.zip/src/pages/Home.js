const Home = () => {


  return <div className="HomeBgd">

    <img className="homeImg" src="/img/ajd.png" style={{ width: "200px", height: "300px" }} />
    <div className="Home">
      <h2>나의 반려견을 위한 <br />맞춤 케어 서비스</h2>
      <p>
        무심코 지나치게 되는 강아지 피부와 안구의 이상 징후,<br />
        사진을 찍어 AI로 집에서 진단을 받아보세요
      </p>
    </div>
    <img className="homeImg2" src="/img/44.png" style={{ width: "180px", height: "250px" }} />
  </div>
}

export default Home;