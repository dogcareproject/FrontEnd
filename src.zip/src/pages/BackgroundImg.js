const BackgroundImg = () => {
  return <div className="background-container">

  </div>
}

export default BackgroundImg